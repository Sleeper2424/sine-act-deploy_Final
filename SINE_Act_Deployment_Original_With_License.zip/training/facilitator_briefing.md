# Simulation Facilitator Briefing

## Role
Guide participants through simulation governance environments. Ensure integrity, neutrality, and accurate process execution.

## Checklist
- [ ] Introduce simulation goals and rules
- [ ] Provide access to the Manifesto
- [ ] Walk through audit logging process
- [ ] Activate harm triggers if necessary

## Reminders
- Your role is neutral; do not shape decisions
- Debrief at end of session with simulation outcomes
- Report participant confusion or concerns to OSS