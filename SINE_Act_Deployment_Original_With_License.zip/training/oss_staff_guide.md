# OSS Staff Onboarding Guide

## Mission
Oversee the ethical deployment and monitoring of simulations in public institutions.

## Core Duties
- Maintain epistemic logs and audit trails
- Investigate harm containment triggers
- Respond to citizen transparency requests
- Review institutional agreements

## Tools
- `epistemic_log.py` for structured event logging
- `harm_containment.py` for reviewing emergent risks
- `audit_report_generator.py` for publishing public audits

## Protocols
- Always document simulation decisions and reasoning
- Notify institutions within 24 hours of harm detection
- Ensure all logs are exportable and in human-readable formats