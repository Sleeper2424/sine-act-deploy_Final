# SINE Act Slide Deck – Speaker Notes

## Sections
1. Why SINE: Protecting Public Autonomy in Simulations
2. The Law: Legislative Draft Highlights
3. Institutions: What Compliance Looks Like
4. Public: The Role of Transparency & Audit Logs
5. OSS: Structure, Staffing, Enforcement Tools

## Core Messages
- Simulations are governance tools — not toys
- Transparency is a civic right
- Simulation harm can be audited, reviewed, and prevented