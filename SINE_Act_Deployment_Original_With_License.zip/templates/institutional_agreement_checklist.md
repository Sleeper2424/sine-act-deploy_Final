# Institutional Simulation Agreement – Checklist

## Responsibilities
- [ ] Disclose all active simulations
- [ ] Provide access to epistemic logs upon request
- [ ] Permit OSS to audit and report simulation outcomes
- [ ] Honor public opt-out and review rights

## Collaboration
- [ ] Share improvements or adaptations with OSS
- [ ] Participate in quarterly transparency briefings

## Compliance Timeline
- [ ] Initial audit scheduled within 90 days
- [ ] Full compliance expected by 18-month deadline