def check_harm(event_type, metadata):
    triggers = ["BiasDetected", "ManipulatedOutcome", "OpaqueInference"]
    if event_type in triggers:
        return f"HARM CONTAINMENT TRIGGERED: {event_type}"
    return "No harm trigger."