def generate_audit_md(events):
    return "\n".join([f"- **{e[0]}** — *{e[1]}* by `{e[2]}` on `{e[3]}`" for e in events])

# Example event: [(datetime, "DecisionType", "Description", "Actor", "SystemID")]