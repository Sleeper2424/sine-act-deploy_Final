import csv
from datetime import datetime

def log_event(event_type, description, actor, system_id, log_path="epistemic_log.csv"):
    with open(log_path, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([datetime.utcnow(), event_type, description, actor, system_id])

# Example usage:
# log_event("PolicyDecision", "Enabled override on budget constraint", "CouncilMember123", "SimSystem-Alpha")