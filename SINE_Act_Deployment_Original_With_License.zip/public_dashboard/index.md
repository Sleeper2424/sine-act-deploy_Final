# 🧾 SINE Act Public Simulation Audit Index

Welcome to the Office of Simulation Stewardship (OSS) public dashboard. Here you will find active simulations, audit logs, and transparency scores.

---

## 🔍 Active Simulations

| Simulation ID | Institution        | Status     | Last Audit     | Transparency Score |
|---------------|--------------------|------------|----------------|--------------------|
| Sim-A001      | Civic High School  | Active     | 2025-07-15     | ✅ Pass            |
| Sim-B038      | CityGov Oakland    | Under Review | 2025-07-10  | ⚠️ Needs Review    |

---

## 📂 Public Logs
- [Sim-A001 Audit Report](./Sim-A001_Audit.md)
- [Sim-B038 Audit Report](./Sim-B038_Audit.md)

---

## 🛠 How to File a Concern
If you believe a simulation in your institution has violated transparency or caused harm, [file a complaint with OSS](mailto:oss@civicnet.gov) or attend your next civic oversight hearing.